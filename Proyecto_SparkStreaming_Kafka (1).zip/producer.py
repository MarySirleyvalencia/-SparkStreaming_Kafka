from kafka import KafkaProducer
import json
import time
import random

producer = KafkaProducer(
    bootstrap_servers=['localhost:9092'],
    value_serializer=lambda v: json.dumps(v).encode('utf-8')
)

while True:
    data = {
        'usuario': random.choice(['Carlos', 'Ana', 'Luis', 'María']),
        'accion': random.choice(['login', 'logout', 'compra', 'busqueda']),
        'valor': random.randint(1, 500),
        'timestamp': time.strftime('%Y-%m-%d %H:%M:%S')
    }
    producer.send('datos_tiempo_real', data)
    print(f"Evento enviado: {data}")
    time.sleep(2)
